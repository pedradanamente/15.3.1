CREATE TABLE `subscribers` (
`email` VARCHAR( 255 ) NOT NULL ,
`subscribed_at` DATETIME NOT NULL
)